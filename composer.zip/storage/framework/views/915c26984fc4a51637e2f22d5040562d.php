

<?php $__env->startSection('content'); ?>
<div class="max-w-3xl mx-auto py-6">
    <div class="flex items-center justify-between mb-4">
        <h1 class="text-2xl font-semibold">Editar usuario</h1>
        <a href="<?php echo e(route('settings.index')); ?>" class="px-4 py-2 bg-gray-200 rounded">Volver</a>
    </div>

    <div class="bg-white shadow rounded p-6">
        <form method="POST" action="<?php echo e(route('settings.update', $user)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-4">
                <label class="block text-sm font-medium">Nombre</label>
                <input name="name" value="<?php echo e(old('name', $user->name)); ?>" class="mt-1 block w-full rounded border-gray-300" required />
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-4">
                <label class="block text-sm font-medium">Email</label>
                <input name="email" value="<?php echo e(old('email', $user->email)); ?>" class="mt-1 block w-full rounded border-gray-300" required />
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-4">
                <label class="block text-sm font-medium">Rol</label>
                <select name="role" class="mt-1 block w-full rounded border-gray-300" required>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($r->slug); ?>" <?php echo e(old('role', optional($user->role)->slug) == $r->slug ? 'selected' : ''); ?>><?php echo e(ucfirst($r->name)); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="mb-4">
                <label class="block text-sm font-medium">Supervisor</label>
                <select name="supervisor_id" class="mt-1 block w-full rounded border-gray-300">
                    <option value="">- Ninguno -</option>
                    <?php $__currentLoopData = $supervisors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($s->id); ?>" <?php echo e(old('supervisor_id', $user->supervisor_id) == $s->id ? 'selected' : ''); ?>><?php echo e($s->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="flex justify-end">
                <button class="px-4 py-2 bg-indigo-600 text-white rounded">Guardar</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\skynet-api\resources\views\settings\edit.blade.php ENDPATH**/ ?>