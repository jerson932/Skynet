<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Visita #<?php echo e($visit->id); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="mx-auto max-w-5xl space-y-6 sm:px-6 lg:px-8">

            
            <div class="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
                <div class="grid gap-4 sm:grid-cols-2">
                    <div>
                        <h3 class="mb-2 text-sm font-semibold text-gray-600">Cliente</h3>
                        <div class="text-lg font-medium text-gray-900">
                            <?php echo e($visit->client->name); ?>

                        </div>
                        <?php if($visit->client->contact_name): ?>
                            <div class="text-sm text-gray-600">Contacto: <?php echo e($visit->client->contact_name); ?></div>
                        <?php endif; ?>
                        <?php if($visit->client->phone): ?>
                            <div class="text-sm text-gray-600">Teléfono: <?php echo e($visit->client->phone); ?></div>
                        <?php endif; ?>
                        <?php if($visit->client->email): ?>
                            <div class="text-sm text-gray-600">Email: <?php echo e($visit->client->email); ?></div>
                        <?php endif; ?>
                        <?php if($visit->client->address): ?>
                            <div class="text-sm text-gray-600">Dirección: <?php echo e($visit->client->address); ?></div>
                        <?php endif; ?>
                        
                    </div>

                                        
                    <div class="mt-4">
                        <h3 class="text-lg font-semibold text-gray-800">Notas</h3>
                        <p class="mt-1 text-gray-600">
                            <?php echo e($visit->notes ?? '— Sin notas —'); ?>

                        </p>
                    </div>

                    <div>
                        <h3 class="mb-2 text-sm font-semibold text-gray-600">Asignación</h3>
                        <div class="text-sm text-gray-700">Técnico: <?php echo e($visit->tecnico->name); ?></div>
                        <div class="text-sm text-gray-700">Supervisor: <?php echo e($visit->supervisor->name); ?></div>
                        <div class="text-sm text-gray-700">Programada:
                            <?php echo e(optional($visit->scheduled_at)->format('Y-m-d H:i')); ?>

                        </div>
                        <div class="mt-3 flex flex-wrap gap-2">
                            <?php
                                $lat = $visit->client->lat;
                                $lng = $visit->client->lng;
                            ?>
                            <?php if(!is_null($lat) && !is_null($lng)): ?>
                                <a target="_blank"
                                   href="https://www.google.com/maps/search/?api=1&query=<?php echo e($lat); ?>,<?php echo e($lng); ?>"
                                   class="rounded-lg bg-blue-600 px-3 py-2 text-xs font-semibold text-white hover:bg-blue-700">
                                   Ver en Google Maps
                                </a>
                                <a target="_blank"
                                   href="https://www.google.com/maps/dir/?api=1&destination=<?php echo e($lat); ?>,<?php echo e($lng); ?>"
                                   class="rounded-lg bg-emerald-600 px-3 py-2 text-xs font-semibold text-white hover:bg-emerald-700">
                                   Navegar (Google)
                                </a>
                                <a target="_blank"
                                   href="https://www.openstreetmap.org/directions?engine=fossgis_osrm_car&route=%3B<?php echo e($lat); ?>,<?php echo e($lng); ?>"
                                   class="rounded-lg bg-gray-800 px-3 py-2 text-xs font-semibold text-white hover:bg-gray-900">
                                   Navegar (OSM)
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
                <h3 class="mb-3 text-sm font-semibold text-gray-600">Ubicación del cliente</h3>

                <?php if(!is_null($visit->client->lat) && !is_null($visit->client->lng)): ?>
                    <div id="map"
                         data-lat="<?php echo e($visit->client->lat); ?>"
                         data-lng="<?php echo e($visit->client->lng); ?>"
                         style="height: 360px; border-radius:.75rem; overflow:hidden; background:#f3f4f6;">
                    </div>
                    <p class="mt-2 text-xs text-gray-500">
                        Puedes acercar/alejar el mapa y tocar el marcador para ver coordenadas.
                    </p>
                <?php else: ?>
                    <div class="rounded-lg bg-amber-50 p-4 text-amber-800">
                        Este cliente aún no tiene coordenadas registradas (lat/lng).
                    </div>
                <?php endif; ?>
            </div>

            
            <div class="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
                <div class="flex flex-wrap gap-2">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('mark', $visit)): ?>
                        <?php if(!$visit->check_in_at): ?>
                            <form action="<?php echo e(route('visits.checkin', $visit)); ?>" method="POST" onsubmit="return fillGeo(this)">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="lat">
                                <input type="hidden" name="lng">
                                <button class="rounded-lg bg-blue-600 px-4 py-2 text-white hover:bg-blue-700">
                                    Check-in
                                </button>
                            </form>
                        <?php endif; ?>

                        <?php if($visit->check_in_at && !$visit->check_out_at): ?>
                            <form action="<?php echo e(route('visits.checkout', $visit)); ?>" method="POST" onsubmit="return fillGeo(this)">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="lat">
                                <input type="hidden" name="lng">
                                <button class="rounded-lg bg-emerald-600 px-4 py-2 text-white hover:bg-emerald-700">
                                    Check-out
                                </button>
                            </form>
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php if(!empty($visit->client->email)): ?>
                        <form action="<?php echo e(route('visits.sendmail', $visit)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="rounded-lg bg-indigo-600 px-4 py-2 text-white hover:bg-indigo-700">
                                Enviar correo
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    
    <script>
        async function fillGeo(form) {
            const lat = form.querySelector('input[name="lat"]');
            const lng = form.querySelector('input[name="lng"]');
            if (!navigator.geolocation) { alert('Tu navegador no permite geolocalización.'); return false; }
            const getPosition = () => new Promise((res, rej) => {
                navigator.geolocation.getCurrentPosition(res, rej, { enableHighAccuracy: true, timeout: 8000, maximumAge: 0 });
            });
            try {
                const pos = await getPosition();
                lat.value = pos.coords.latitude.toFixed(6);
                lng.value = pos.coords.longitude.toFixed(6);
                return true;
            } catch(e) {
                alert('No se pudo obtener tu ubicación. Activa GPS/ubicación e inténtalo otra vez.');
                return false;
            }
        }
    </script>

    
    <?php if(!is_null($visit->client->lat) && !is_null($visit->client->lng)): ?>
        <?php if (! $__env->hasRenderedOnce('ea7c59a4-97c2-4643-bc2c-9f6e90dc9388')): $__env->markAsRenderedOnce('ea7c59a4-97c2-4643-bc2c-9f6e90dc9388'); ?>
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" crossorigin="anonymous"/>
        <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" crossorigin="anonymous"></script>
        <?php endif; ?>

        <script>
        (function(){
            function init() {
                const div = document.getElementById('map');
                if (!div || typeof L === 'undefined') return;

                const lat = parseFloat(div.dataset.lat);
                const lng = parseFloat(div.dataset.lng);
                const map = L.map(div).setView([lat, lng], 16);

                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    maxZoom: 19, attribution: '&copy; OpenStreetMap'
                }).addTo(map);

                const marker = L.marker([lat, lng]).addTo(map).bindPopup('Cliente').openPopup();
                setTimeout(() => map.invalidateSize(true), 150); // evita “mapa gris”
            }
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', init, { once:true });
            } else {
                init();
            }
        })();
        </script>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\skynet-api\resources\views\visits\show.blade.php ENDPATH**/ ?>