<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Reporte de Visita #<?php echo e($visit->id); ?></title>
  <style>
    body{ font-family: DejaVu Sans, sans-serif; font-size:12px; }
    h1{ font-size:18px; margin:0 0 10px; }
    .box{ border:1px solid #333; padding:10px; margin-bottom:10px; }
    .row{ margin:4px 0; }
    .label{ font-weight:bold; width:160px; display:inline-block; }
    small{ color:#666; }
  </style>
</head>
<body>
  <h1>Reporte de Visita #<?php echo e($visit->id); ?></h1>

  <div class="box">
    <div class="row"><span class="label">Cliente:</span> <?php echo e($visit->client->name); ?></div>
    <div class="row"><span class="label">Técnico:</span> <?php echo e($visit->tecnico->name); ?></div>
    <div class="row"><span class="label">Supervisor:</span> <?php echo e($visit->supervisor->name); ?></div>
    <div class="row"><span class="label">Programada:</span> <?php echo e(optional($visit->scheduled_at)->format('Y-m-d H:i')); ?></div>
  </div>

  <div class="box">
    <div class="row"><span class="label">Check-in:</span> <?php echo e(optional($visit->check_in_at)->format('Y-m-d H:i')); ?></div>
    <div class="row"><span class="label">Lat/Lng:</span> <?php echo e($visit->check_in_lat); ?>, <?php echo e($visit->check_in_lng); ?></div>
  </div>

  <div class="box">
    <div class="row"><span class="label">Check-out:</span> <?php echo e(optional($visit->check_out_at)->format('Y-m-d H:i')); ?></div>
    <div class="row"><span class="label">Lat/Lng:</span> <?php echo e($visit->check_out_lat); ?>, <?php echo e($visit->check_out_lng); ?></div>
  </div>

  <div class="box">
    <div class="row"><span class="label">Notas:</span> <?php echo e($visit->notes ?? '—'); ?></div>
  </div>

  <small>Generado por <?php echo e(config('app.name')); ?> el <?php echo e(now()->format('Y-m-d H:i')); ?></small>
</body>
</html>
<?php /**PATH C:\laragon\www\skynet-api\resources\views\pdf\visit.blade.php ENDPATH**/ ?>