

<?php $__env->startSection('content'); ?>
<div class="max-w-3xl mx-auto py-6">
    <div class="bg-white p-6 rounded shadow">
        <h2 class="text-xl font-semibold mb-4"><?php echo e(isset($user) ? 'Técnico: '.$user->name : 'Mi supervisor'); ?></h2>

        <?php if($supervisor): ?>
            <div class="space-y-2">
                <div><strong>Nombre:</strong> <?php echo e($supervisor->name); ?></div>
                <div><strong>Email:</strong> <?php echo e($supervisor->email); ?></div>
            </div>
        <?php else: ?>
            <div class="text-gray-600">No tienes un supervisor asignado.</div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\skynet-api\resources\views\settings\tecnico.blade.php ENDPATH**/ ?>