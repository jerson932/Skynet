<?php if($paginator->hasPages()): ?>
    <nav role="navigation" aria-label="Pagination Navigation" class="flex items-center justify-center py-4">
        <ul class="inline-flex items-center -space-x-px rounded-md overflow-hidden">
            
            <?php if($paginator->onFirstPage()): ?>
                <li class="px-2 py-1 bg-white text-gray-300 border border-gray-200">&laquo;</li>
            <?php else: ?>
                <li>
                    <a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" class="px-3 py-1 bg-white border border-gray-200 text-gray-700 hover:bg-gray-50">&laquo;</a>
                </li>
            <?php endif; ?>

            
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if(is_string($element)): ?>
                    <li class="px-3 py-1 bg-white border border-gray-200 text-gray-500"><?php echo e($element); ?></li>
                <?php endif; ?>

                
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <li class="px-3 py-1 bg-blue-600 text-white border border-blue-600"><?php echo e($page); ?></li>
                        <?php else: ?>
                            <li><a href="<?php echo e($url); ?>" class="px-3 py-1 bg-white border border-gray-200 text-gray-700 hover:bg-gray-50"><?php echo e($page); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <li>
                    <a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" class="px-3 py-1 bg-white border border-gray-200 text-gray-700 hover:bg-gray-50">&raquo;</a>
                </li>
            <?php else: ?>
                <li class="px-2 py-1 bg-white text-gray-300 border border-gray-200">&raquo;</li>
            <?php endif; ?>
        </ul>
    </nav>
<?php endif; ?>
<?php /**PATH C:\laragon\www\skynet-api\resources\views/vendor/pagination/tailwind.blade.php ENDPATH**/ ?>