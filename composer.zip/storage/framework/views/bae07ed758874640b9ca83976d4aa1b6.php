<?php $__env->startComponent('mail::message'); ?>
# Visita finalizada

**Cliente:** <?php echo e($visit->client->name); ?>  
**Técnico:** <?php echo e($visit->tecnico->name); ?>  
**Programada:** <?php echo e(optional($visit->scheduled_at)->format('Y-m-d H:i')); ?>


<?php $__env->startComponent('mail::panel'); ?>
**Check-in:** <?php echo e(optional($visit->check_in_at)->format('Y-m-d H:i')); ?>  
Lat/Lng: <?php echo e($visit->check_in_lat); ?>, <?php echo e($visit->check_in_lng); ?>


**Check-out:** <?php echo e(optional($visit->check_out_at)->format('Y-m-d H:i')); ?>  
Lat/Lng: <?php echo e($visit->check_out_lat); ?>, <?php echo e($visit->check_out_lng); ?>

<?php echo $__env->renderComponent(); ?>

**Notas:**  
<?php echo e($visit->notes ?? '—'); ?>


<?php $__env->startComponent('mail::button', ['url' => 'https://www.google.com/maps/dir/?api=1&destination='.$visit->check_out_lat.','.$visit->check_out_lng]); ?>
Ver ubicación de salida
<?php echo $__env->renderComponent(); ?>

Gracias,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\laragon\www\skynet-api\resources\views\emails\visits\closed.blade.php ENDPATH**/ ?>