<img 
    src="<?php echo e(asset('images/skynet-logo.png')); ?>" 
    alt="Skynet Logo" 
    <?php echo e($attributes->merge(['class' => 'h-16 w-auto mx-auto'])); ?>

><?php /**PATH C:\laragon\www\skynet-api\resources\views\components\application-logo.blade.php ENDPATH**/ ?>