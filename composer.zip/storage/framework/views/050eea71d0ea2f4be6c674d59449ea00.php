

<?php $__env->startSection('content'); ?>
<div class="max-w-lg mx-auto py-8">
    <h1 class="text-2xl font-semibold mb-4">Cambiar contraseña</h1>

    <div class="bg-white shadow rounded p-6">
        <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <form method="POST" action="<?php echo e(route('password.change.update')); ?>">
            <?php echo csrf_field(); ?>

            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700">Nueva contraseña</label>
                <input type="password" name="password" required class="mt-1 block w-full rounded border-gray-300 shadow-sm" />
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700">Confirmar contraseña</label>
                <input type="password" name="password_confirmation" required class="mt-1 block w-full rounded border-gray-300 shadow-sm" />
            </div>

            <div class="flex items-center justify-between">
                <a href="<?php echo e(route('dashboard')); ?>" class="text-sm text-gray-600">Volver</a>
                <button type="submit" class="px-4 py-2 bg-indigo-600 text-white rounded">Actualizar contraseña</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\skynet-api\resources\views\auth\change-password.blade.php ENDPATH**/ ?>