<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Visitas
                <?php if(request('date')): ?>
                    <span class="text-gray-500">(<?php echo e(request('date')); ?>)</span>
                <?php else: ?>
                    <span class="text-gray-500">(todas)</span>
                <?php endif; ?>
            </h2>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\Visit::class)): ?>
            <a href="<?php echo e(route('visits.create')); ?>"
               class="inline-flex items-center gap-2 rounded-xl bg-blue-600 px-4 py-2 text-white shadow hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500">
                <svg class="h-5 w-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>
                </svg>
                Nueva visita
            </a>

         
            <?php endif; ?>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="mx-auto max-w-7xl space-y-4 sm:px-6 lg:px-8">

            <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            
            <form method="GET" class="flex w-full flex-col items-start gap-3 sm:flex-row sm:items-center">
                <label class="text-sm text-gray-600">Fecha</label>
                <input type="date" name="date" value="<?php echo e(request('date')); ?>"
                       class="w-full max-w-xs rounded-lg border-gray-300 px-3 py-2 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                <button
                    class="rounded-lg bg-gray-900 px-4 py-2 text-white shadow hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-gray-600">
                    Filtrar
                </button>
                <?php if(request('date')): ?>
                    <a href="<?php echo e(route('visits.index')); ?>" class="rounded-lg px-4 py-2 border border-gray-300 text-gray-700 hover:bg-gray-50">
                        Limpiar
                    </a>
                <?php endif; ?>
            </form>

            
            <form id="visits-export-form" method="GET" action="<?php echo e(route('visits.export')); ?>" target="visits-download-iframe" class="flex w-full flex-col items-start gap-2 sm:flex-row sm:items-center">
                <input type="hidden" name="format" value="xlsx">
                <label class="text-sm text-gray-600">Exportar</label>
                <input type="date" name="from" value="<?php echo e(request('from')); ?>" class="w-full max-w-xs rounded-lg border-gray-300 px-3 py-2 shadow-sm">
                <input type="date" name="to" value="<?php echo e(request('to')); ?>" class="w-full max-w-xs rounded-lg border-gray-300 px-3 py-2 shadow-sm">

                <button id="export-xlsx" type="submit" name="format" value="xlsx" class="inline-flex items-center gap-2 rounded-lg bg-green-600 px-4 py-2 text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500">
                    <svg class="spinner hidden h-4 w-4 animate-spin text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path>
                    </svg>
                    <span class="btn-text">Exportar XLSX</span>
                </button>
            </form>
            
            <iframe id="visits-download-iframe" name="visits-download-iframe" style="display:none;width:0;height:0;border:0;"></iframe>

            <div class="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
                <div class="overflow-x-auto">
                    <table class="min-w-full text-sm">
                        <thead>
                            <tr class="bg-gray-50 text-left text-gray-600">
                                <th class="px-4 py-3 font-medium">#</th>
                                <th class="px-4 py-3 font-medium">Cliente</th>
                                <th class="px-4 py-3 font-medium">Técnico</th>
                                <th class="px-4 py-3 font-medium">Programada</th>
                                <th class="px-4 py-3 font-medium">Check-in</th>
                                <th class="px-4 py-3 font-medium">Check-out</th>
                                <th class="px-4 py-3 font-medium">Estado</th>
                                <th class="px-4 py-3 text-right font-medium">Acciones</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            <?php $__empty_1 = true; $__currentLoopData = $visits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php
                                    $status = $v->check_out_at ? 'completada' : ($v->check_in_at ? 'en curso' : 'pendiente');
                                ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-4 py-3 text-gray-500"><?php echo e($v->id); ?></td>
                                    <td class="px-4 py-3 font-medium text-gray-900"><?php echo e($v->client->name); ?></td>
                                    <td class="px-4 py-3 text-gray-800"><?php echo e($v->tecnico->name); ?></td>
                                    <td class="px-4 py-3 text-gray-800">
                                        <?php echo e(optional($v->scheduled_at)->format('Y-m-d H:i')); ?>

                                    </td>
                                      
                                    
                                    
                                    <td class="px-4 py-3">
                                        <?php if($v->check_in_at): ?>
                                            <div class="font-medium text-gray-900"><?php echo e($v->check_in_at->format('H:i')); ?></div>
                                            <div class="text-xs text-gray-500">
                                                <?php echo e($v->check_in_lat); ?>, <?php echo e($v->check_in_lng); ?>

                                            </div>
                                        <?php else: ?>
                                            <span class="text-gray-400">—</span>
                                        <?php endif; ?>
                                    </td>

                                    
                                    <td class="px-4 py-3">
                                        <?php if($v->check_out_at): ?>
                                            <div class="font-medium text-gray-900"><?php echo e($v->check_out_at->format('H:i')); ?></div>
                                            <div class="text-xs text-gray-500">
                                                <?php echo e($v->check_out_lat); ?>, <?php echo e($v->check_out_lng); ?>

                                            </div>
                                        <?php else: ?>
                                            <span class="text-gray-400">—</span>
                                        <?php endif; ?>
                                    </td>

                                    
                                    
                                    <td class="px-4 py-3">
                                        <?php if($status === 'completada'): ?>
                                            <span class="rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold text-emerald-800">Completada</span>
                                        <?php elseif($status === 'en curso'): ?>
                                            <span class="rounded-full bg-amber-100 px-3 py-1 text-xs font-semibold text-amber-800">En curso</span>
                                        <?php else: ?>
                                            <span class="rounded-full bg-gray-100 px-3 py-1 text-xs font-semibold text-gray-800">Pendiente</span>
                                        <?php endif; ?>
                                    </td>

                                    
                                    <td class="px-4 py-3">
                                        <div class="flex justify-end gap-2 flex-wrap">

                                        
                                        <a href="<?php echo e(route('visits.show', $v)); ?>"
                                        class="inline-flex items-center gap-2 rounded-lg bg-gray-200 px-3 py-1.5 text-xs font-semibold text-gray-800 hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-400">
                                        Ver
                                        </a>

                                            
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('mark', $v)): ?>
                                                <?php if(!$v->check_in_at): ?>
                                                    <form action="<?php echo e(route('visits.checkin', $v)); ?>" method="POST" class="inline" onsubmit="return fillGeo(this)">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="lat">
                                                        <input type="hidden" name="lng">
                                                        <button
                                                            class="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-semibold text-white shadow hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500">
                                                            Check-in
                                                        </button>
                                                    </form>
                                                <?php endif; ?>

                                                <?php if($v->check_in_at && !$v->check_out_at): ?>
                                                    <form action="<?php echo e(route('visits.checkout', $v)); ?>" method="POST" class="inline" onsubmit="return fillGeo(this)">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="lat">
                                                        <input type="hidden" name="lng">
                                                        <button
                                                            class="inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white shadow hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-emerald-500">
                                                            Check-out
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                            <?php endif; ?>

                                            
                                            <?php if(!empty($v->client->email)): ?>
                                                <form action="<?php echo e(route('visits.sendmail', $v)); ?>" method="POST" class="inline">
                                                    <?php echo csrf_field(); ?>
                                                    <button
                                                        class="inline-flex items-center gap-2 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white shadow hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                                        title="Enviar correo de visita">
                                                        <svg class="h-4 w-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" d="M3 8l9 6 9-6M5 19h14a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2z"/>
                                                        </svg>
                                                        Enviar
                                                    </button>
                                                </form>
                                            <?php endif; ?>

                                            
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $v)): ?>
                                                <a href="<?php echo e(route('visits.edit', $v)); ?>"
                                                   class="inline-flex items-center gap-2 rounded-lg bg-amber-500 px-3 py-1.5 text-xs font-semibold text-white shadow hover:bg-amber-600">
                                                    Editar
                                                </a>
                                            <?php endif; ?>

                                            
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $v)): ?>
                                                <form action="<?php echo e(route('visits.destroy', $v)); ?>" method="POST" class="inline"
                                                      onsubmit="return confirm('¿Eliminar la visita #<?php echo e($v->id); ?>?')">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button
                                                        class="inline-flex items-center gap-2 rounded-lg bg-red-600 px-3 py-1.5 text-xs font-semibold text-white shadow hover:bg-red-700">
                                                        Eliminar
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8" class="px-4 py-8 text-center text-gray-500">Sin visitas</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="border-t px-4 py-3">
                    <?php echo e($visits->withQueryString()->links()); ?>

                </div>
            </div>
        </div>
    </div>

    
    <script>
        async function fillGeo(form) {
            const lat = form.querySelector('input[name="lat"]');
            const lng = form.querySelector('input[name="lng"]');

            if (!navigator.geolocation) {
                alert('Tu navegador no permite geolocalización.');
                return false;
            }

            const getPosition = () => new Promise((resolve, reject) => {
                navigator.geolocation.getCurrentPosition(resolve, reject, {
                    enableHighAccuracy: true, timeout: 8000, maximumAge: 0
                });
            });

            try {
                const pos = await getPosition();
                lat.value = pos.coords.latitude.toFixed(6);
                lng.value = pos.coords.longitude.toFixed(6);
                return true; // envía el form
            } catch (e) {
                alert('No se pudo obtener tu ubicación. Activa GPS/ubicación e inténtalo otra vez.');
                return false;
            }
        }
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('visits-export-form');
            const btn = document.getElementById('export-xlsx');
            const iframe = document.getElementById('visits-download-iframe');
            if (!form || !btn) return;

            let exportTimeout = null;
            const EXPORT_TIMEOUT_MS = 45000; // 45 seconds fallback

            form.addEventListener('submit', function (e) {
                // show spinner and disable button to prevent double-click
                const spinner = btn.querySelector('.spinner');
                const text = btn.querySelector('.btn-text');
                if (spinner) spinner.classList.remove('hidden');
                if (text) text.textContent = 'Generando...';
                btn.disabled = true;

                // set a fallback timeout to restore the button if iframe doesn't fire
                if (exportTimeout) clearTimeout(exportTimeout);
                exportTimeout = setTimeout(() => {
                    if (spinner) spinner.classList.add('hidden');
                    if (text) text.textContent = 'Exportar XLSX';
                    btn.disabled = false;
                    // optional: notify user
                    try { window.alert('La generación tardó demasiado. Intenta nuevamente o revisa la conexión.'); } catch (e) {}
                }, EXPORT_TIMEOUT_MS);
            });

            // when iframe finishes loading (download completed or error page), restore button
            if (iframe) {
                iframe.addEventListener('load', function () {
                    if (exportTimeout) { clearTimeout(exportTimeout); exportTimeout = null; }
                    const spinner = btn.querySelector('.spinner');
                    const text = btn.querySelector('.btn-text');
                    if (spinner) spinner.classList.add('hidden');
                    if (text) text.textContent = 'Exportar XLSX';
                    btn.disabled = false;
                });

                // if user returns focus (maybe blocked permission dialogs), restore state
                window.addEventListener('focus', function () {
                    if (exportTimeout) { clearTimeout(exportTimeout); exportTimeout = null; }
                    const spinner = btn.querySelector('.spinner');
                    const text = btn.querySelector('.btn-text');
                    if (spinner) spinner.classList.add('hidden');
                    if (text) text.textContent = 'Exportar XLSX';
                    btn.disabled = false;
                });
            }
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\skynet-api\resources\views\visits\index.blade.php ENDPATH**/ ?>