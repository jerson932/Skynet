<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-gray-800">Clientes</h2>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\Client::class)): ?>
            <a href="<?php echo e(route('clients.web.create')); ?>" class="px-4 py-2 bg-blue-600 text-white rounded">Nuevo</a>
            <?php endif; ?>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="p-6 max-w-5xl mx-auto space-y-4">
        <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <form class="flex gap-2">
            <input name="q" value="<?php echo e($q); ?>" placeholder="Buscar nombre o email" class="border rounded px-3 py-2 w-full max-w-md">
            <button class="px-4 py-2 bg-gray-900 text-white rounded">Buscar</button>
        </form>

        <div class="bg-white rounded border overflow-hidden">
            <table class="min-w-full text-sm">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-3 py-2 text-left">#</th>
                        <th class="px-3 py-2 text-left">Nombre</th>
                        <th class="px-3 py-2 text-left">Email</th>
                        <th class="px-3 py-2 text-left">Teléfono</th>
                        <th class="px-3 py-2 text-right">Acciones</th>
                    </tr>
                </thead>
                <tbody class="divide-y">
                    <?php $__empty_1 = true; $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="px-3 py-2"><?php echo e($c->id); ?></td>
                        <td class="px-3 py-2"><?php echo e($c->name); ?></td>
                        <td class="px-3 py-2"><?php echo e($c->email ?? '—'); ?></td>
                        <td class="px-3 py-2"><?php echo e($c->phone ?? '—'); ?></td>
                        <td class="px-3 py-2 text-right flex gap-2 justify-end">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $c)): ?>
                            <a href="<?php echo e(route('clients.web.edit', $c)); ?>" class="px-3 py-1 bg-amber-500 text-white rounded">Editar</a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $c)): ?>
                            <form action="<?php echo e(route('clients.web.destroy', $c)); ?>" method="POST" onsubmit="return confirm('¿Eliminar?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="px-3 py-1 bg-red-600 text-white rounded">Eliminar</button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5" class="px-3 py-6 text-center text-gray-500">Sin clientes</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php echo e($clients->withQueryString()->links()); ?>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\skynet-api\resources\views/clients/index.blade.php ENDPATH**/ ?>