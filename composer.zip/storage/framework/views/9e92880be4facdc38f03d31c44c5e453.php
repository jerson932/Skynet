

<?php $__env->startSection('content'); ?>
<div class="max-w-3xl mx-auto py-6">
    <div class="flex items-center justify-between mb-4">
        <h1 class="text-2xl font-semibold">Asignar técnicos a <?php echo e($user->name); ?></h1>
        <a href="<?php echo e(route('settings.index')); ?>" class="px-4 py-2 bg-gray-200 rounded">Volver</a>
    </div>

    <div class="bg-white shadow rounded p-6">
        <form method="POST" action="<?php echo e(route('settings.assign.store', $user)); ?>">
            <?php echo csrf_field(); ?>

            <div class="space-y-2">
                <?php $__currentLoopData = $tecnicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $assignedToOther = $t->supervisor_id && $t->supervisor_id !== $user->id; ?>
                    <label class="flex items-center gap-3">
                        <input type="checkbox" name="tecnicos[]" value="<?php echo e($t->id); ?>" <?php echo e($t->supervisor_id == $user->id ? 'checked' : ''); ?> <?php echo e($assignedToOther ? 'disabled' : ''); ?>>
                        <span class="ml-2"><?php echo e($t->name); ?> — <small class="text-gray-500"><?php echo e($t->email); ?></small>
                            <?php if($assignedToOther): ?>
                                <span class="ml-2 text-xs text-red-500">(Asignado a <?php echo e(optional($t->supervisor)->name); ?>)</span>
                            <?php endif; ?>
                        </span>
                    </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="mt-4 text-right">
                <button class="px-4 py-2 bg-indigo-600 text-white rounded">Guardar asignaciones</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\skynet-api\resources\views/settings/assign.blade.php ENDPATH**/ ?>