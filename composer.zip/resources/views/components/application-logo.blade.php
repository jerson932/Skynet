<img 
    src="{{ asset('images/skynet-logo.png') }}" 
    alt="Skynet Logo" 
    {{ $attributes->merge(['class' => 'h-16 w-auto mx-auto']) }}
>